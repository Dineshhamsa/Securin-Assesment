###1. Total Combinations are possible for Die's rolling together
Combinations=0

for Die_A in range(1,7):
    for Die_B in range(1,7):
        Combinations=Combinations+1
print("Total Combinations:",Combinations)

###2. Distribution of all possible Combinations rolling together
for Die_A in range(1,7):
    for Die_B in range(1,7):
        print("({},{})".format(Die_A,Die_B),end='')
    print()
    
###3. Probability of all possible sums occuring combinations
Sum={}
for Die_A in range(1,7):
    for Die_B in range(1,7):
        total=(Die_A+Die_B)
        if total in Sum:
            Sum[total]=Sum[total]+1
        else:
            Sum[total]=1
for value in Sum.keys():
    count = Sum[value]
    probability = count / Combinations
    print("P(Sum = {}) = {:.4f}".format(value, probability))